# Classe que representa um livro
class Livro:
    titulo = ""
    autor = ""
    ano = 0
    codigo = ""
    status = ""


# Exibe os dados de um livro
def exibir_livro(livro):
    print()
    print(f"Título: {livro.titulo}")
    print(f"Autor: {livro.autor}")
    print(f"Ano: {livro.ano}")
    print(f"Código: {livro.codigo}")
    print(f"Status: {livro.status}")
    print()


# Cadastro de livros
def cadastrar_livro(biblioteca):
    codigo = input("Código: ")

    for livro in biblioteca:
        if livro.codigo == codigo:
            print("Código já cadastrado!")
            return

    livro = Livro()

    livro.titulo = input("Título: ")
    livro.autor = input("Autor: ")
    livro.ano = int(input("Ano de publicação: "))
    livro.codigo = codigo
    livro.status = "Disponível"

    biblioteca.append(livro)

    print("Livro cadastrado com sucesso!")


# Consulta por código ou autor
def consultar_livro(biblioteca):
    print("1 - Buscar por código")
    print("2 - Buscar por autor")

    opcao = input("Escolha: ")

    if opcao == "1":
        codigo = input("Código: ")

        for livro in biblioteca:
            if livro.codigo == codigo:
                exibir_livro(livro)
                return

        print("Livro não encontrado")

    else:
        if opcao == "2":
            autor = input("Autor: ")
            encontrou = False

            for livro in biblioteca:
                if livro.autor.lower() == autor.lower():
                    exibir_livro(livro)
                    encontrou = True

            if encontrou == False:
                print("Livro não encontrado")

        else:
            print("Opção inválida")


# Alteração dos dados do livro
def alterar_dados(biblioteca):
    codigo = input("Código do livro: ")

    for livro in biblioteca:
        if livro.codigo == codigo:
            livro.titulo = input("Novo título: ")
            livro.autor = input("Novo autor: ")
            livro.ano = int(input("Novo ano: "))

            print("Dados alterados com sucesso!")
            return

    print("Livro não encontrado")


# Remoção de livros
def remover_livro(biblioteca):
    codigo = input("Código do livro: ")

    for livro in biblioteca:
        if livro.codigo == codigo:
            biblioteca.remove(livro)
            print("Livro removido com sucesso!")
            return

    print("Livro não encontrado")


# Ordenação dos livros por título
def ordenar_livros(biblioteca):
    tamanho = len(biblioteca)

    for i in range(tamanho - 1):
        for j in range(tamanho - i - 1):

            titulo1 = biblioteca[j].titulo.lower()
            titulo2 = biblioteca[j + 1].titulo.lower()

            # Troca de posição dos livros
            if titulo1 > titulo2:
                auxiliar = biblioteca[j]
                biblioteca[j] = biblioteca[j + 1]
                biblioteca[j + 1] = auxiliar


# Listagem de todos os livros
def listar_todos(biblioteca):
    if len(biblioteca) == 0:
        print("Nenhum livro cadastrado.")
        return

    ordenar_livros(biblioteca)

    print("LIVROS CADASTRADOS")

    for livro in biblioteca:
        print(f"{livro.titulo} - {livro.ano}")


# Realização de empréstimos
def realizar_emprestimo(biblioteca):
    codigo = input("Código do livro: ")

    for livro in biblioteca:
        if livro.codigo == codigo:

            if livro.status == "Emprestado":
                print("Livro já emprestado")

            else:
                livro.status = "Emprestado"
                print("Empréstimo realizado com sucesso!")

            return

    print("Livro não encontrado")


# Realização de devoluções
def realizar_devolucao(biblioteca):
    codigo = input("Código do livro: ")

    for livro in biblioteca:
        if livro.codigo == codigo:
            livro.status = "Disponível"
            print("Devolução realizada com sucesso!")
            return

    print("Livro não encontrado")


# Menu principal do sistema
def menu():
    biblioteca = []
    sair = False

    while sair == False:

        print("\nBIBLIOTECA")
        print("1 - Cadastrar livro")
        print("2 - Consultar livro")
        print("3 - Alterar dados")
        print("4 - Remover livro")
        print("5 - Listar todos")
        print("6 - Realizar empréstimo")
        print("7 - Realizar devolução")
        print("8 - Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            cadastrar_livro(biblioteca)

        else:
            if opcao == "2":
                consultar_livro(biblioteca)

            else:
                if opcao == "3":
                    alterar_dados(biblioteca)

                else:
                    if opcao == "4":
                        remover_livro(biblioteca)

                    else:
                        if opcao == "5":
                            listar_todos(biblioteca)

                        else:
                            if opcao == "6":
                                realizar_emprestimo(biblioteca)

                            else:
                                if opcao == "7":
                                    realizar_devolucao(biblioteca)

                                else:
                                    if opcao == "8":
                                        sair = True
                                        print("Programa encerrado.")

                                    else:
                                        print("Opção inválida")


menu()